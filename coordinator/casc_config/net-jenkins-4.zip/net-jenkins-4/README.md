# net-jenkins
A Dockerfile and some bash scripts for setting up a Jenkins server locally, as part of a DEV article series around .NET Continuous Integrations
