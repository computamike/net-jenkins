import jenkins.model.*
Jenkins.instance.setNumExecutors(1)
